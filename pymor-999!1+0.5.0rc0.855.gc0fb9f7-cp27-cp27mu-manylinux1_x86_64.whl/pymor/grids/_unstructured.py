raise ImportError('''
Cython extension module 'pymor.grids._unstructured' has not been built.
Please run 'python setup.py build_ext --inplace' in the root
directory of the pyMOR repository.''')
